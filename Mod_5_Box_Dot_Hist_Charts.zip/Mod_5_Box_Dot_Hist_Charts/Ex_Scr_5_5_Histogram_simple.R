#################### Simple Histogram ############################# 
##Script to produce Histogram
## STEP 1: SETUP & Source File  - Uses manual input    
	rm(list=ls())
	oldpar<- par(no.readonly=T) 
	script<- "C:/Learn_R/Mod_5_Box_Dot_Hist/Ex_Scr_5_5_Histogram_simple.R"
	par(las=1)
	par(xaxs="i"); par(yaxs="i") # set X & Y axis 
	par(mar=c(3,4,3,2)); par(oma=c(2,1,1,1))
	t_par <- 1.1                  # Title size adjustment factor
	n_par <-1				# Note size adjustment factor	
	par(ps=10); par(mgp=c(1.75,.5,0)); par(tcl = -0.5)
## STEP 2: READ DATA 
my_scores <- c(9.6,10.2,11.6,12,13.2,13.2,13.2,13.5,13.6,
		14.6,15.2,15.4,15.4,15.8,15.9,16.2,16.5,16.6,
		17.1,17.3,17.6,17.6,17.6,17.8,17.9,18,18.1,18.4,18.8)
## STEP 3: MANIPULATE DATA
## STEP 4: CREATE PLOT
hist(my_scores, freq = T, breaks = 10,border="black",
	labels=T, xlim = c(8, 20), ylim = c(0,12), col = "darkgrey",
	xlab = "Exam Score", ylab= "Number of Students",cex.main=t_par, 
	main = "Histogram of Exam Results: \nScore out of possible 20 points")
axis(1, at=seq(8, 20, 1)) 
## Outer margin annotation 
     my_date <- format(Sys.time(), "%m/%d/%y")
     mtext(script, side = 1, line = .5, cex=0.9, outer = T, adj = 0)
     mtext(my_date, side = 1, line =.5, cex = 0.7, outer = T, adj = 1)
## STEP 5: CLOSE
par(oldpar)
#detach(my_data)

