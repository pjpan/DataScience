#################### Box_plot_example.R ############################# 
##Script to produce box plot
## STEP 1: SETUP - Source File  
  rm(list=ls()) 
  oldpar<- par(no.readonly=T) 
  par(las=1); par(oma=c(2,4,0,2)); par(mar=c(3,3,3,1))
  link <- "C:\\Learn_R\\Mod_5_box_dot_hist_charts\\iris_data.txt"
  script <- "C:/Learn_R/Mod_5_box_dot_hist_charts/Ex_Scr_5_1_Box_plot_example.R"
## STEP 2: READ DATA
   my_data <- read.table(link,
             sep = ",",   dec=".",   skip = 0,
             row.names = NULL,    header = TRUE,
             colClasses = c(rep("numeric", 4), "factor"),
             na.strings = c("", "*", "-", -99.99,99.9, 999.9))
## STEP 3: MANIPULATE DATA
   Title <- "Box Plot Example\nIris Flower Data Set: Sepal Length"
## STEP 4: CREATE PLOT with margin text showing script file path
   boxplot(Sepal.L ~ Species, data = my_data, 
      col = "blue", horizontal = FALSE, 
      par(cex = 0.65),whisklty=1,
      outline = TRUE,  boxfill = "grey", 
      boxwex = 0.5, border = "darkgrey", pch = 16, 
  	outcex = 1.25, outcol = "red", main  = Title)
## Outer margin annotation 
     my_date <- format(Sys.time(), "%m/%d/%y")
     mtext(script, side = 1, line = .5, cex=0.7, outer = T, adj = 0)
     mtext(my_date, side = 1, line =.5, cex = 0.7, outer = T, adj = 1)
## STEP 5: CLOSE
par(oldpar)




