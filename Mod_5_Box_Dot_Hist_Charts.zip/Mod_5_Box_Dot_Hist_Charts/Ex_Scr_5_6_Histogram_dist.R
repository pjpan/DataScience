#################### Histogram with distribution and median ############################# 
##Script to produce Histogram with distribution and median
## STEP 1: SETUP & Source File  - Uses manual input
  rm(list=ls())
  oldpar<- par(no.readonly=T) 
  script<- "C:/Learn_R/Mod_5_Box_Dot_Hist/Ex_Scr_5_6_Histogram_dist.R"
  	par(las=1); par(oma=c(2,1,1,1))
	par(xaxs="i"); par(yaxs="i") # set X & Y axis 	
	par(mar=c(3,4,3,2))
	t_par <- 1.1                  # Title size adjustment factor
	n_par <-1				# Note size adjustment factor	
	par(ps=8); par(mgp=c(1.75,.5,0)); par(tcl = -0.5)
## STEP 2: READ DATA 
my_scores <- c(9.6,10.2,11.6,12,13.2,13.2,13.2,13.5,13.6,
		14.6,15.2,15.4,15.4,15.8,15.9,16.2,16.5,16.6,
		17.1,17.3,17.6,17.6,17.6,17.8,17.9,18,18.1,18.4,18.8)
## STEP 3: MANIPULATE DATA
  	numbr <- NROW(my_scores)
	s_max <- max(my_scores)
	s_min <-  min(my_scores)
	s_mean <- signif(mean(my_scores),3)
	s_median <- median(my_scores)
	st_d <- sd(my_scores)
## STEP 4: CREATE PLOT
hist(my_scores, freq = T, breaks = 10,border="black",
	labels=T, xlim = c(8, 20), ylim = c(0,12), col = "darkgrey",
	xlab = "Exam Score", ylab= "Number of Students",cex.main=t_par, 
	main = "Histogram of Exam Results with Additional Information: \nScore out of possible 20 points")
axis(1, at=seq(8, 20, 1)) 
#  Add normal distribution line for mean & std-dev
	lines(my_scores, dnorm(my_scores, mean = s_mean, sd=st_d)* numbr, lwd=1.5, col = "blue")
## Construct multiline text note to be placed on plot 
	my_note <- paste("Summary of Results for ", numbr, " tests\n ",
		s_min, " Minimum score \n ",
		s_median, " Median score \n ",
		s_mean, " Mean score \n ",
		s_max, " Max score")
### Add median line
	x <- c(s_median, s_median)  # x & y coordinates for median line
	y <- c(5,12)
	points(x,y,   col= "pink", type = "l")  # add median line to plot
	arrows(s_median, 10, s_median-1, 10, col = "grey", length = 0.1)
	arrows(s_median, 10, s_median+1, 10, col = "grey", length = 0.1)
## Add Chart annotation
   bel <- subset(my_scores, my_scores < s_median)
   above <- subset(my_scores, my_scores >= s_median)
n_bel <- length(bel)
n_above <- length(above)
	text( s_median-0.3,10.2,n_bel, cex=n_par)
	text(s_median + 0.3, 10.2, n_above, cex = n_par)
	text(9,8, my_note, adj = 0)
## Outer margin annotation 
     my_date <- format(Sys.time(), "%m/%d/%y")
     mtext(script, side = 1, line = .5, cex=1, outer = T, adj = 0)
     mtext(my_date, side = 1, line =.5, cex = 1, outer = T, adj = 1)
## STEP 5: CLOSE
par(oldpar)



