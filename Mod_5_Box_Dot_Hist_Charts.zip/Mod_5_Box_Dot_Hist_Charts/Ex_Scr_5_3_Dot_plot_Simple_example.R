#################### Dot_plot_Simple_example.R ############################# 
##Script to simple dot plot
## STEP 1: SETUP &  Source File
  rm(list=ls()) 
  oldpar<- par(no.readonly=T) 
  par(las=1); par(oma=c(2,4,0,2)); par(mar=c(3,3,3,1))
  link <- "C:\\Learn_R\\Mod_5_Box_Dot_Hist_Charts\\dot_plot_data.txt"
  script <- "C:/Learn_R/Mod_5_Box_Dot_Hist_Charts/Dot_plot_Simple_example.R"
## STEP 2: READ DATA
   my_data <- read.table(link,
             sep = ",",   dec=".",   skip = 0,
             row.names = NULL,    header = FALSE,
             colClasses = c("character","numeric", "factor"),
             na.strings = c("", "*", "-", -99.99,99.9, 999.9),
             col.names = c("Fuel", "Quad_BTU", "Type") )
attach(my_data)
## STEP 3: MANIPULATE DATA
   Title <- "USA Energy Consumption by Source - 2007"
   Source <- "Source: Energy Information Administration"
## STEP 4: CREATE PLOT
 dotchart(Quad_BTU, labels = Fuel,	
 	main = Title, cex = 0.7,  
	xlab = "Quadrillion BTU",
	pch = 16, col = "blue",
	lcolor = NULL)
 text(5,0.5, cex=0.65, pos=4, Source)
## Outer margin annotation 
     my_date <- format(Sys.time(), "%m/%d/%y")
     mtext(script, side = 1, line = .5, cex=0.7, outer = T, adj = 0)
     mtext(my_date, side = 1, line =.5, cex = 0.7, outer = T, adj = 1)
## STEP 5: CLOSE
par(oldpar)
#detach(my_data)

