#################### Dot_plot_Group_example.R ############################# 
##Script to produce Group dot plot
## STEP 1: SETUP & Source File
  rm(list=ls())
  link <- "C:\\Learn_R\\Mod_5_Box_Dot_Hist_Charts\\dot_plot_data.txt"
  script <- "C:/Learn_R/Mod_5_Box_Dot_Hist_Charts/Dot_plot_Group_example.R"
  par(las=1); par(oma=c(2,2,0,1)); par(mar=c(3,3,3,3))
## STEP 2: READ DATA
   my_data <- read.table(link,
             sep = ",",   dec=".",   skip = 0,
             row.names = NULL,    header = FALSE,
             colClasses = c("character","numeric", "factor"),
             na.strings = c("", "*", "-", -99.99,99.9, 999.9),
             col.names = c("Fuel", "Quad_BTU", "Type") )
   ## Make sure number colClasses = number of col.names ##
   attach(my_data)
## STEP 3: MANIPULATE DATA
   Title <- "USA Energy Consumption by Source - 2007"
   Source <- "Source: Energy information Administration"
## STEP 4: CREATE PLOT
 dotchart(Quad_BTU, labels = Fuel, groups = Type,	
    main = Title, cex = 0.6, xlab = "Quadrillion BTU",
    pch = 16, col = "blue", lcolor = NULL, gcolor = "red")	
 text(5,0.5, cex=0.7, pos=4, Source)
## Outer margin annotation 
     my_date <- format(Sys.time(), "%m/%d/%y")
     mtext(script, side = 1, line = .5, cex=0.7, outer = T, adj = 0)
     mtext(my_date, side = 1, line =.5, cex = 0.7, outer = T, adj = 1)
## STEP 5: CLOSE
par(oldpar)
#detach(my_data)


        

