#################### stripchart_example.R ############################# 
##Script to produce strip chart
## STEP 1: SETUP - Source File  
  rm(list-ls())
  oldpar = par(no.readonly=T) 
  script <- "C:/Learn_R/Mod_5_box_dot_hist_charts/Ex_5_7_stripchart_example.R"
  link <- "C:\\Learn_R\\Mod_5_Box_Dot_Hist_Charts\\iris_data.txt"
  par(mar=c(2,4,3,2)); par(oma=c(3,3,3,3))
  par(las=1); par(ps=10)
## STEP 2: READ DATA
   my_data <- read.table(link,
             sep = ",",   dec=".",   skip = 0,
             row.names = NULL,    header = TRUE,
             colClasses = c(rep("numeric", 4), "factor"),
             na.strings = c("", "*", "-", -99.99,99.9, 999.9))
## STEP 3: MANIPULATE DATA
   Title <- "Strip Chart Example\nIris Flower Data Set: Sepal Length"
   
## STEP 4: CREATE PLOT with margin text showing script file path
   stripchart(Sepal.L ~ Species, data = my_data, 
      col = "grey", main  = Title, font.main=2, vertical = T, 
	pch = 16, font.axis = 1,cex=1., cex.main = 1.2, cex.axis = 1.1)
	 ## Outer margin annotation 
     my_date <- format(Sys.time(), "%m/%d/%y")
     mtext(script, side = 1, line = .5, cex=.7, outer = T, adj = 0)
     mtext(my_date, side = 1, line =.5, cex = .7, outer = T, adj = 1)
## STEP 5: CLOSE
par(oldpar)



